"""
    Submodule for
       t  topological
       r  recurrent
       e  epsilon
       m  machines (with)
       u  uniform
       p  probabilities.
"""
